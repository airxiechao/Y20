#!/bin/bash

sudo systemctl restart  y20-agent-client.service

exit
